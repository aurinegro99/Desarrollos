function ValidaHorometro(faena,equipo,fecha,horometro,constante,flag,componente,posicion,motivo,ejecutor,litros)
{
    
	var v = document.ifrmx.document.frm;
	v.reset ();
	v.faena.value = faena;
	v.equipo.value = equipo;
	v.fecha.value = fecha;
	v.horometro.value =  horometro;
	v.constante.value =  constante;
	v.flag.value =  flag;
	v.ejecutor.value =  ejecutor;
	v.motivo_muestra.value =  motivo;
	v.litros.value =  litros;
	v.componente.value =  componente;
	v.posicion.value =  posicion;
	v.action = "ifrm_cambioaceite.php";
	v.target = "ifrm1";
	v.submit ();
}